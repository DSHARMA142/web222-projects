/**
 * WEB222 – Assignment 04
 *
 * I declare that this assignment is my own work in accordance with
 * Seneca Academic Policy. No part of this assignment has been
 * copied manually or electronically from any other source
 * (including web sites) or distributed to other students.
 *
 * Please update the following with your information:
 *
 *      Name:       Divyanshu Sharma
 *      Student ID: 172551210
 *      Date:       3 Aprill, 2023
 */

// All of our data is available on the global `window` object.
// Create local variables to work with it in this file.
const { products, categories } = window;

// For debugging, display all of our data in the console

window.onload = function () {
  categories.forEach((element) => {
    var mainDiv = document.querySelector("#menu");
    var btn = document.createElement("button");
    btn.id = element.id;
    btn.title = element.name;
    btn.className = "button";
    btn.textContent = element.name;
    btn.addEventListener("click", setActiveClass);
    mainDiv.append(btn);
  });

  var menuItem = document.getElementsByClassName("button");
  var menuLink = menuItem[0];
  menuLink.className += " active";

  var active_menu = document.getElementsByClassName("active");

  var selectedCategory = document.querySelector("#selected-category");
  var head = document.createElement("h2");
  head.textContent = active_menu[0].innerHTML;

  selectedCategory.innerHTML = "";
  selectedCategory.append(head);

  showProductsByCategory(active_menu[0].id);
};
function setActiveClass(active) {
  var elem = document.getElementsByClassName("button");

  [].forEach.call(elem, function (a) {
    a.classList.remove("active");
  });

  var target = active.target || active.srcElement;
  target.className += " active";
  var selectedCategory = document.querySelector("#selected-category");
  var head = document.createElement("h2");
  head.textContent = target.innerText;

  selectedCategory.innerHTML = "";
  selectedCategory.append(head);

  showProductsByCategory(target.id);
}

function showProductsByCategory(id) {
  var mainDiv = document.querySelector("#container");
  mainDiv.innerHTML = "";
  products.forEach((element) => {
    var category = element.categories;

    if (category.includes(id)) {
      if (element.discontinued === false) {
        var card = createProductCard(element);
        mainDiv.appendChild(card);
      }
    }
  });
}

function createProductCard(product) {
  // Create a <div> to hold the card
  const card = document.createElement("div");
  // Add the .card class to the <div>
  card.classList.add("card");

  // Create a product image, use the .card-image class
  const productImage = document.createElement("img");
  productImage.src = product.imageUrl;
  productImage.classList.add("card-image");
  card.appendChild(productImage);

  // ... rest of your card building code here
  const sub_div = document.createElement("div");
  sub_div.classList.add("card__details");

  const title_div = document.createElement("div");
  title_div.classList.add("name");
  title_div.innerText = product.title;
  sub_div.appendChild(title_div);

  const price_span = document.createElement("span");
  price_span.innerText = new Intl.NumberFormat("en-CA", {
    style: "currency",
    currency: "CAD"
  }).format(product.price / 100);
  sub_div.appendChild(price_span);

  const desc = document.createElement("p");
  desc.classList.add("product_desc");
  desc.title = product.description;
  desc.innerText = product.description;
  sub_div.appendChild(desc);

  card.appendChild(sub_div);
  // Return the card’s <div> element to the caller
  return card;
}

// For debugging, display all of our data in the console
console.log({ products, categories }, "Store Data");
