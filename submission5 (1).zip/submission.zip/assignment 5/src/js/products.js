/**
 * products.js
 *
 * The store's products are defined as an Array of product Objects.
 * Each product Object includes the following properties:
 *
 *  - id: String, a unique product identifier (e.g., "P1", "P2")
 *  - title: String, a short name for the product (e.g., "Gingerbread Cookie")
 *  - description: String, a description of the product
 *  - price: Number, the unit price of the item in whole cents (e.g., 100 = $1.00, 5379 = $53.79)
 *  - discontinued: Boolean, whether or not the product has been discontinued
 *  - categories: Array, the category id or ids to which this product belongs (e.g., ["c1"] or ["c1", "c2"])
 */

 window.products = [
  {
    id: "10000",
    title: "pythopyt",
    description:
      "Gucci Pour Homme II is a gorgeous fragrance with a fresh and calming scent. This fragrance opens with a fresh scent of green violet leaves, supported by a soothing, calming scent of black tea. It  is an amazing fragrance to wear during the spring, summer, and fall.",
    price: 6680000,
    discontinued: false,
    categories: ["MEN"],
    imageUrl: "images/1.jpg"

  },

  {
    id: "10001",
    title: "Gucci Guilty",
    description:
      "Gucci Guilty is a fantastic fragrance with a fresh and aromatic scent. This fragrance opens with a fresh and slightly sweet scent of lemon, supported by an aromatic scent of lavender. This creates a great opening with a very likable and pleasant scent.",
    price: 58000000,
    discontinued: false,
    categories: ["MEN"],
    imageUrl: "images/2.jpg"

  },

  {
    id: "10002",
    title: "Gucci Envy",
    description:
      "Gucci Envy is a beautiful fragrance with a warm scent of woods and spices. This fragrance opens with a bunch of different notes, including fresh lavender and ginger, as well as a few spicy notes. This creates a beautiful, gentlemanly scent that only becomes nicer. A little while after the opening, the fragrance turns a little warmer with the addition of the woody notes.",
    price: 4360000,
    discontinued: false,
    categories: ["MEN"],
    imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSOcoXySjKwYhMyZ8Lr2NqQHJjxxr4jE7HvXh3sDJ8uNIZM_jDPcO9iwBGFm3tIx65Ks9o&usqp=CAU"
  },

  {
    id: "10003",
    title: "Gucci By Gucci Sport",
    description:
      "Gucci By Gucci Sport is a gorgeous fragrance with a fresh and sporty scent. This fragrance opens with a beautiful scent of fresh and juicy citruses, supported by a green touch of cypress. A little while after the opening, a sweet scent of fig starts to appear. Along with the fig are some fresh spicy notes, giving the fragrance some body.",
    price: 2100000,
    discontinued: false,
    categories: ["MEN"],
    imageUrl: "images/3.jpg"

  },

  {
    id: "10004",
    title: "Gucci Memoire d’Une Odeur",
    description:
      "Gucci Memoire d’Une Odeur is a great fragrance with a fresh and herbal scent. This fragrance opens with a powdery and fresh scent of florals, supported by the note of almond. Shortly after the opening, a nice touch of musk is added, blending in nicely with the powdery feel. As this fragrance starts to dry down, some woody notes start to come forth.",
    price: 1510700,
    discontinued: false,
    categories: ["WOMEN"],
    imageUrl: "https://www.usmagazine.com/wp-content/uploads/2022/09/p422093-av-06-zoom1.webp?crop=0px%2C486px%2C1500px%2C848px&resize=1600%2C900&quality=86&strip=all"
  },

  {
    id: "10005",
    title: "Gucci Made To Measure",
    description:
      "Gucci Made To Measure is a fantastic fragrance with a fresh and safe scent. This fragrance opens with a light and fresh scent of citruses and floral notes, creating a very likable opening.",
    price: 550039000,
    discontinued: false,
    categories: ["MEN"],
    imageUrl: "https://resize-elle.ladmedia.fr/alias/original/img/var/plain_site/storage/images/media/images/gucci7/90695174-1-fre-FR/gucci.jpg"
  },

  {
    id: "10006",
    title: "Gucci Guilty Cologne",
    description:
      "Gucci Guilty Cologne is a fantastic fragrance with a fresh take on the original Gucci Guilty DNA. This fragrance opens with a very fresh scent of citruses and herbal notes. Added to that is the note of juniper berries, which gives off an almost gin-like scent. This adds a sharp freshness to the fragrance, making it even nicer.",
    price: 10800000,
    discontinued: false,
    categories: ["WOMEN"],
    imageUrl: "https://www.dapperconfidential.com/wp-content/uploads/2019/01/gucci-guilty-1-720x540.jpg"
  },

  {
    id: "10007",
    title: "Gucci Premiere Eau De Parfum Natural Spray for Women",
    description:
      "The Gucci Premiere for women takes its inspiration from the glamorous Hollywood and celebrates the star in every woman. With top notes of blackberry and bergamot, heart notes of orange blossoms and white flowers, and base notes of patchouli and sandalwood, the perfume becomes an aromatic scent for women.",
    price: 8520000,
    discontinued: false,
    categories: ["WOMEN"],
    imageUrl: "https://www.dapperconfidential.com/wp-content/uploads/2019/04/Gucci-Guilty-Intense-Pour-Homme-ED-524x500.jpg.webp"
  },

  {
    id: "10008",
    title: "Gucci Rush Eau De Toilette Spray for Women",
    description:
      "The Rush Eau De Toilette Spray by Gucci has a spicy, floral fragrance that is irresistible and lingers to leave a trace of the scent wherever you go. The top notes of the fragrance are freesia and gardenia, and heart notes are jasmine, Turkish rose, and coriander, while the base notes are made with patchouli, vanilla, and vetiver.",
    price: 9765500,
    discontinued: false,
    categories: ["WOMEN"],
    imageUrl: "images/5.jpg"


  },
  {
    id: "10009",
    title: "Gucci Flora Eau De Toilette Spray for Women",
    description:
      "Filled in a hexagon-shaped bottle and colorful floral packaging, Gucci Flora is defined as feminine and sensual fragrance. The top notes of the Flora collection are mandarin and peony, while the heart is enriched with the rare Osmanthus flower, pink pepper, and rose.",
    price: 9845800,
    discontinued: false,
    categories: ["WOMEN"],
    imageUrl: "images/6.jpg"

  },

  {
    id: "10010",
    title: "Gucci Envy Me Eau De Toilette Spray for Women",
    description:
      "The light reflections on the case sides and lugs highlight the elegant profile of the 28 mm Oyster case, which is fitted with a fluted bezel. Rolex's classic feminine watch, the Lady-Datejust is in the lineage of the Datejust, the emblematic model that has been a byword for style and accurate timekeeping.",
    price: 2996500,
    discontinued: false,
    categories: ["WOMEN"],
    imageUrl: "https://cdn.shoplightspeed.com/shops/663517/files/47617542/500x500x2/image.jpg"
  },

  {
    id: "10011",
    title: "Flora by Gucci Eau De Parfum Spray for Women",
    description:
      "A long-lasting and strong fragrance from Gucci’s Flora range of perfumes is the Gucci Flora Eau De Parfum Spray. The brand claims that the perfume is intense, rich, and seductive. The EDP spray features a hexagon-shaped glass flacon decorated with a black bow ribbon and gold detailing.",
    price: 2460000,
    discontinued: false,
    categories: ["WOMEN"],
    imageUrl: "https://www.usmagazine.com/wp-content/uploads/2022/09/4-3.webp?w=1200&quality=86&strip=all"

  },

  {
    id: "10012",
    title: "Gucci by Gucci Eau De Parfum Spray for Women",
    description:
      "Simple yet stronger, Gucci for Women is a basic perfume for women. Composed with a mix of fruity and floral fragrances, the Eau De Parfum was released as the main fragrance for ladies.",
    price: 898650,
    discontinued: false,
    categories: ["WOMEN"],
    imageUrl: "https://www.dapperconfidential.com/wp-content/uploads/2019/04/Gucci-Guilty-Intense-Pour-Homme-ED-524x500.jpg.webp"

  },

  {
    id: "10013",
    title: "Gucci Bloom",
    description:
      "Bloom by Gucci is a beautiful fragrance with a white floral scent. The fragrance will transport you to a wonderful garden full of blooming flowers. Imagine walking through this garden and basking in all the floral scents.",
    price: 98000,
    discontinued: false,
    categories: ["CHILDREN"],
    imageUrl: "images/9.jpg"

  },

  {
    id: "10014",
    title: "Gucci by Gucci",
    description:
      "Gucci is named the main fragrance of the brand by many. In fact, it is supposed to convey the essence of Gucci. The fragrance is intoxicating and mouthwatering. With honey, musk, and patchouli at the base, and pear and guava at the top, the fragrance is very sweet and fruity. Notes of patchouli, honey, and guava, however, steal the show.",
    price: 98700,
    discontinued: false,
    categories: ["CHILDREN"],
    imageUrl: "https://cdn.mos.cms.futurecdn.net/qWDV9CSijLGET3bwQGH7j.jpg"
  },

  {
    id: "10015",
    title: "Gucci Bamboo",
    description:
      "Bamboo by Gucci is the scent of femininity and confidence. It is inspired by the modern day woman who can do it all and smell like flowers while at it. The fragrance is floral and citrusy. The main notes of lily, bergamot, and orange blossom will bring out the woman in you. It is a fragrance for when you want to feel grown and mature, yet fresh and seductive. Bamboo opens with floral notes and follows with a vanilla and woody dry down.",
    price: 876540,
    discontinued: false,
    categories: ["CHILDREN"],
    imageUrl: "images/10.jpg"

  },

  {
    id: "10016",
    title: "Gucci Premiere",
    description:
      "Premiere will give you your very own Hollywood moment on the red carpet. Imagine Blake Lively, a traditional movie star beauty. This fragrance was made to celebrate women and turn heads. It has a sparkling bright opening with sandalwood and patchouli at the base, and orange blossom at the heart.",
    price: 98400,
    discontinued: false,
    categories: ["CHILDREN"],
    imageUrl: "https://cdn.mos.cms.futurecdn.net/ZTKwEYYpdrrUKwKPwNw6dj.jpg"
  },

  {
    id: "10017",
    title: "Gucci Made to Measure for Men",
    description:
      "Made to Measure is the male partner in crime to Gucci Premiere. The fragrance will give you oriental spice, luxury, and sophistication. Much like a suit, it falls into place on your skin. You will sense lavender, plum, and leather, along with the less pronounced notes of cinnamon, amber, and juniper berries.",
    price: 26765000,
    discontinued: false,
    categories: ["MEN"],
    imageUrl: "https://m.media-amazon.com/images/W/IMAGERENDERING_521856-T1/images/I/8124oQwkUDL._AC_SY450_.jpg"
  },

  {
    id: "10018",
    title: "Rush Gucci For Women",
    description:
      "Rush is a floral fragrance that was released in 1998. It contains a blend of rose, lily of the valley and carnation. This perfume is perfect for daywear and is best suited for women who want to feel confident and beautiful. The scent is light and fresh, and it’s ideal for wearing during the spring and summer months.",
    price: 7896000,
    discontinued: false,
    categories: ["CHILDREN"],
    imageUrl: "images/11.jpg"

  },

  {
    id: "10019",
    title: "Memoire D’une Odeur Gucci For Women And Men",
    description:
      "MDM&eacute;moire d’une Odeur was released in 2018 and is a floral fragrance that contains a blend of jasmine, tuberose and orange blossom. This perfume is perfect for day or night wear and is best suited for people who want to feel romantic and nostalgic. The scent is delicate and dreamy, and it’s perfect for wearing during the spring and summer months.",
    price: 858000,
    discontinued: false,
    categories: ["MEN", "WOMEN"],
    imageUrl:"https://cf.shopee.com.my/file/5f109f63555db6bd1f1372b89877279e"
  },

  {
    id: "10020",
    title: "Flora By Gucci Gorgeous Gardenia Gucci For Women",
    description:
      "Flora by Gucci Gorgeous Gardenia was released in 2011 and is a floral fragrance that contains a blend of gardenia, jasmine and tuberose. This perfume is perfect for day or night wear and is best suited for women who want to feel feminine and beautiful. The scent is delicate and romantic, and it’s perfect for wearing during the spring and summer months.",
    price: 14200000,
    discontinued: false,
    categories: ["WOMEN"],
    imageUrl: "images/12.jpg"

  }
];
