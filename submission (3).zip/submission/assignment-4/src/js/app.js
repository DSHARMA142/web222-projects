/**
 * WEB222 – Assignment 04
 *
 * I declare that this assignment is my own work in accordance with
 * Seneca Academic Policy. No part of this assignment has been
 * copied manually or electronically from any other source
 * (including web sites) or distributed to other students.
 *
 * Please update the following with your information:
 *
 *      Name:       Divyanshu Sharma
 *      Student ID: 172551210
 *      Date:       22 March 2023
 */

// All of our data is available on the global `window` object.
// Create local variables to work with it in this file.
const { products, categories } = window;

// For debugging, display all of our data in the console

let arrM = [];
let arrWM = [];
let arrC = [];

for (let i = 0; i < products.length; i++) {
  products[i].categories.forEach(function (element) {
    if (element === "MEN" && products[i].discontinued === false) {
      arrM.push(products[i].description);
    } else if (element === "WOMEN" && products[i].discontinued === false) {
      arrWM.push(products[i].description);
    } else if (element === "CHILDREN" && products[i].discontinued === false) {
      arrC.push(products[i].description);
    }
  });
}

let menu = document.getElementById("menu");
for (let i = 0; i < categories.length; i++) {
  let newMenuItem = document.createElement("button");
  newMenuItem.textContent = categories[i].name;
  newMenuItem.id = categories[i].name;
  menu.appendChild(newMenuItem);
}

function printdis(category) {
  let tableRows = document.getElementsByClassName("tbl-row");

  if (category === "MEN") {
    for (let i = 0; i < arrM.length; i++) {
      tableRows[i].addEventListener("click", function () {
        console.log(arrM[i]);
      });
    }
  } else if (category === "WOMEN") {
    for (let i = 0; i < arrWM.length; i++) {
      tableRows[i].addEventListener("click", function () {
        console.log(arrWM[i]);
      });
    }
  } else if (category === "CHILDREN") {
    for (let i = 0; i < arrC.length; i++) {
      tableRows[i].addEventListener("click", function () {
        console.log(arrC[i]);
      });
    }
  }
}

function createcell(category) {
  var tbodyRef = document.getElementById("categoryProducts");
  var newRow, newCell, newText;

  for (let i = 0; i < products.length; i++) {
    document.createElement("tr");

    products[i].categories.forEach(function (element) {
      if (element === category && products[i].discontinued === false) {
        newRow = tbodyRef.insertRow();
        newRow.className = "tbl-row";

        newCell = newRow.insertCell();
        newText = document.createTextNode(products[i].title);
        newCell.appendChild(newText);

        newCell = newRow.insertCell();
        newCell.id = i;
        newText = document.createTextNode(products[i].description);
        newCell.appendChild(newText);

        newCell = newRow.insertCell();
        newText = document.createTextNode(
          (products[i].price / 100).toLocaleString("en-CA", { currency: "CAD", style: "currency" })
        );
        newCell.appendChild(newText);
      }
    });
  }
}

document.getElementById("categoryProducts").innerHTML = "";
document.getElementById("selected-category").textContent = "Men";
createcell("MEN");

function show_products(category) {
  document.getElementById("categoryProducts").innerHTML = "";

  for (let j = 0; j < categories.length; j++) {
    if (categories[j].name === category) {
      category = categories[j].id;
    }
  }

  createcell(category);
  printdis(category);
}

let arrMenu = document.querySelector("#menu").querySelectorAll("button");
for (let i = 0; i < arrMenu.length; i++) {
  arrMenu[i].addEventListener("click", function () {
    document.getElementById("selected-category").innerHTML = arrMenu[i].textContent;
    show_products(arrMenu[i].textContent);
  });
}

printdis("MEN");
