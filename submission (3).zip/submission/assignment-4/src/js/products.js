/**
 * products.js
 *
 * The store's products are defined as an Array of product Objects.
 * Each product Object includes the following properties:
 *
 *  - id: String, a unique product identifier (e.g., "P1", "P2")
 *  - title: String, a short name for the product (e.g., "Gingerbread Cookie")
 *  - description: String, a description of the product
 *  - price: Number, the unit price of the item in whole cents (e.g., 100 = $1.00, 5379 = $53.79)
 *  - discontinued: Boolean, whether or not the product has been discontinued
 *  - categories: Array, the category id or ids to which this product belongs (e.g., ["c1"] or ["c1", "c2"])
 */

window.products = [
  {
    id: "10000",
    title: "Lavender Haze",
    description:
      " LAVENDER HAZE is a gorgeous fragrance with a fresh and calming scent. This fragrance opens with a fresh scent of green violet leaves, supported by a soothing, calming scent of black tea. It  is an amazing fragrance to wear during the spring, summer, and fall.",
    price: 920000,
    discontinued: false,
    categories: ["MEN"]
  },

  {
    id: "10001",
    title: "Vouitton Vigante",
    description:
      " is a fantastic fragrance with a fresh and aromatic scent. This fragrance opens with a fresh and slightly sweet scent of lemon, supported by an aromatic scent of lavender. This creates a great opening with a very likable and pleasant scent.",
    price: 58000000,
    discontinued: false,
    categories: ["MEN"]
  },

  {
    id: "10002",
    title: "LV CLASSIC SERIES",
    description:
      "THE CLASSIC SERIES ARE fragrance SETS with a warm scent of woods and spices. This fragrance opens with a bunch of different notes, including fresh lavender and ginger, as well as a few spicy notes. This creates a beautiful, gentlemanly scent that only becomes nicer. A little while after the opening, the fragrance turns a little warmer with the addition of the woody notes.",
    price: 4360000,
    discontinued: false,
    categories: ["MEN"]
  },

  {
    id: "10003",
    title: "DARK DREAM",
    description:
      "Celebrating the boundless emotion of a day spent in the sun, On the Beach is an ode to the Californian Coast, its exhilarating atmosphere and its iconic scenery. This vivid summer scent starts with an explosion of freshness thanks to bright yuzu and sun-drenched neroli, while thyme, rosemary, pink pepper and cloves add sandy notes and cypress provides a sense of shade.",
    price: 2100000,
    discontinued: false,
    categories: ["MEN"]
  },

  {
    id: "10004",
    title: "Louis Memoire d’Une Odeur",
    description:
      "Conveying the enchantment of a sunset, California Dream holds on to this special emotion, prolonging the happiness of a summer day in those last moments of daylight. To capture the visual marvel that is a setting sun, this composition begins with notes of energetic mandarin and warm musk, leading way to balmy vanilla-tinged benzoin.",
    price: 1510700,
    discontinued: false,
    categories: ["WOMEN"]
  },

  {
    id: "10005",
    title: "DREAMS",
    description:
      "Like plunging into the ocean of the senses, Afternoon Swim evokes the emotion of the sea as it washes over the skin on a beautiful summer day. A groundswell of citrus invigorates this fragrance, with exhilarating notes of orange, bergamot and mandarin invigorated by a touch of ginger and grounded by ambergris.",
    price: 550039000,
    discontinued: false,
    categories: ["MEN"]
  },

  {
    id: "10006",
    title: "DREAMY Cologne",
    description:
      "The collection's first Evening Cologne, City of Stars is a nocturnal fantasy set in a city that never sleeps, telling a tale of endless possibilities, ardent emotion, and soft sensuality. Composed by Jacques Cavallier Belletrud, this dazzling scent conveys light through an explosive citrus quintet of blood orange, lemon, red mandarin, bergamot, and lime, while Tiare flower, sandalwood, and musk exude sophistication, creating a sensual tableau and ushering in the night.",
    price: 10800000,
    discontinued: false,
    categories: ["WOMEN"]
  },

  {
    id: "10007",
    title: "VOUITION Premiere Eau De Parfum Natural Spray for Women",
    description:
      "The VOUITION Premiere for women takes its inspiration from the glamorous Hollywood and celebrates the star in every woman. With top notes of blackberry and bergamot, heart notes of orange blossoms and white flowers, and base notes of patchouli and sandalwood, the perfume becomes an aromatic scent for women.",
    price: 8520000,
    discontinued: false,
    categories: ["WOMEN"]
  },

  {
    id: "10008",
    title: "LV  Rush Eau De Toilette Spray for Women",
    description:
      "The Rush Eau De Toilette Spray by Gucci has a spicy, floral fragrance that is irresistible and lingers to leave a trace of the scent wherever you go. The top notes of the fragrance are freesia and gardenia, and heart notes are jasmine, Turkish rose, and coriander, while the base notes are made with patchouli, vanilla, and vetiver.",
    price: 9765500,
    discontinued: false,
    categories: ["WOMEN"]
  },

  {
    id: "10009",
    title: "LV Flora Eau De Toilette Spray for Women",
    description:
      "Filled in a hexagon-shaped bottle and colorful floral packaging, Gucci Flora is defined as feminine and sensual fragrance. The top notes of the Flora collection are mandarin and peony, while the heart is enriched with the rare Osmanthus flower, pink pepper, and rose.",
    price: 9845800,
    discontinued: false,
    categories: ["WOMEN"]
  },

  {
    id: "10010",
    title: "LV Envy Me Eau De Toilette Spray for Women",
    description:
      "The light reflections on the case sides and lugs highlight the elegant profile of the 28 mm Oyster case, which is fitted with a fluted bezel. Rolex's classic feminine watch, the Lady-Datejust is in the lineage of the Datejust, the emblematic model that has been a byword for style and accurate timekeeping.",
    price: 2996500,
    discontinued: false,
    categories: ["WOMEN"]
  },

  {
    id: "10011",
    title: "Flora by LV Eau De Parfum Spray for Women",
    description:
      "A long-lasting and strong fragrance from Gucci’s Flora range of perfumes is the Gucci Flora Eau De Parfum Spray. The brand claims that the perfume is intense, rich, and seductive. The EDP spray features a hexagon-shaped glass flacon decorated with a black bow ribbon and gold detailing.",
    price: 2460000,
    discontinued: false,
    categories: ["WOMEN"]
  },

  {
    id: "10012",
    title: "LV by GLAZE Eau De Parfum Spray for Women",
    description:
      "Simple yet stronger, Gucci for Women is a basic perfume for women. Composed with a mix of fruity and floral fragrances, the Eau De Parfum was released as the main fragrance for ladies.",
    price: 898650,
    discontinued: false,
    categories: ["WOMEN"]
  },

  {
    id: "10013",
    title: "LOVE Bloom",
    description:
      "Bloom by LOVE is a beautiful fragrance with a white floral scent. The fragrance will transport you to a wonderful garden full of blooming flowers. Imagine walking through this garden and basking in all the floral scents.",
    price: 98000,
    discontinued: false,
    categories: ["CHILDREN"]
  },

  {
    id: "10014",
    title: "VOUTION by LV",
    description:
      "VOUITION is named the main fragrance of the brand by many. In fact, it is supposed to convey the essence of Gucci. The fragrance is intoxicating and mouthwatering. With honey, musk, and patchouli at the base, and pear and guava at the top, the fragrance is very sweet and fruity. Notes of patchouli, honey, and guava, however, steal the show.",
    price: 98700,
    discontinued: false,
    categories: ["CHILDREN"]
  },

  {
    id: "10015",
    title: "LV Bamboo",
    description:
      "Bamboo by LV is the scent of femininity and confidence. It is inspired by the modern day woman who can do it all and smell like flowers while at it. The fragrance is floral and citrusy. The main notes of lily, bergamot, and orange blossom will bring out the woman in you. It is a fragrance for when you want to feel grown and mature, yet fresh and seductive. Bamboo opens with floral notes and follows with a vanilla and woody dry down.",
    price: 876540,
    discontinued: false,
    categories: ["CHILDREN"]
  },

  {
    id: "10016",
    title: "LV Premiere",
    description:
      "Premiere will give you your very own Hollywood moment on the red carpet. Imagine Blake Lively, a traditional movie star beauty. This fragrance was made to celebrate women and turn heads. It has a sparkling bright opening with sandalwood and patchouli at the base, and orange blossom at the heart.",
    price: 98400,
    discontinued: false,
    categories: ["CHILDREN"]
  },

  {
    id: "10017",
    title: "VOUITON Made to Measure for Men",
    description:
      "Made to Measure is the male partner in crime to LV Premiere. The fragrance will give you oriental spice, luxury, and sophistication. Much like a suit, it falls into place on your skin. You will sense lavender, plum, and leather, along with the less pronounced notes of cinnamon, amber, and juniper berries.",
    price: 26765000,
    discontinued: false,
    categories: ["MEN"]
  },

  {
    id: "10018",
    title: "Rush VOUITON For Women",
    description:
      "Rush is a floral fragrance that was released in 1998. It contains a blend of rose, lily of the valley and carnation. This perfume is perfect for daywear and is best suited for women who want to feel confident and beautiful. The scent is light and fresh, and it’s ideal for wearing during the spring and summer months.",
    price: 7896000,
    discontinued: false,
    categories: ["CHILDREN"]
  },

  {
    id: "10019",
    title: "Memoire D’une Odeur LV For Women And Men",
    description:
      "MDM&eacute;moire d’une Odeur was released in 2018 and is a floral fragrance that contains a blend of jasmine, tuberose and orange blossom. This perfume is perfect for day or night wear and is best suited for people who want to feel romantic and nostalgic. The scent is delicate and dreamy, and it’s perfect for wearing during the spring and summer months.",
    price: 858000,
    discontinued: false,
    categories: ["MEN", "WOMEN"]
  },

  {
    id: "10020",
    title: "Flora By LV Gorgeous Gardenia Gucci For Women",
    description:
      "Flora by LV Gorgeous Gardenia was released in 2011 and is a floral fragrance that contains a blend of gardenia, jasmine and tuberose. This perfume is perfect for day or night wear and is best suited for women who want to feel feminine and beautiful. The scent is delicate and romantic, and it’s perfect for wearing during the spring and summer months.",
    price: 14200000,
    discontinued: false,
    categories: ["WOMEN"]
  }
];
